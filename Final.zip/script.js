// let imageAnim = document.getElementById("image-animate");

// // let imageArray = [
// //  "https://cdn.pixabay.com/photo/2022/09/07/10/01/landscape-7438429_960_720.jpg",
// //   "https://cdn.pixabay.com/photo/2022/09/04/20/11/plane-7432680_960_720.jpg",
// //   "https://cdn.pixabay.com/photo/2017/11/04/13/43/texture-2917553_960_720.jpg",
// //   "https://cdn.pixabay.com/photo/2022/07/20/18/44/reading-7334749_960_720.png"
// // ]
// let imageArray = [
 
//   "images/metro-paramount4-1.jpg",
//   "images/metro-paramount6-1.jpg",
//   "images/metro-paramount5-1.jpg",
 
// ]

// let imageIndex = 0;

// const startImage = () =>{
//   imageAnim.setAttribute("src",imageArray[imageIndex]);
//   imageIndex++;
//   if(imageIndex >= imageArray.length){
//     imageIndex = 0;
//   }
// }

// setInterval(startImage,2000);

const myModal = document.getElementById('myModal')
const myInput = document.getElementById('myInput')

myModal.addEventListener('shown.bs.modal', () => {
  myInput.focus()
})


// coursel-effect


// gallery
const boxes = document.querySelectorAll(".images-wrap");
let activeIndex = 1;
let isTransitioning = false;

function updateCurrentImg() {
  isTransitioning = true;

  boxes.forEach((box, index) => {
    const isActive = index === activeIndex;
    images-wrap.classList.toggle("expanded", isActive);
    images-wrap.classList.toggle("closed", !isActive);
  });

  setTimeout(() => {
    isTransitioning = false;
  }, 500);
}

function handleArrowKey(event) {
  if (isTransitioning) {
    return;
  }

  if (event.key === "ArrowRight") {
    activeIndex = (activeIndex + 1) % boxes.length;
  } else if (event.key === "ArrowLeft") {
    activeIndex = (activeIndex - 1 + boxes.length) % boxes.length;
  }

  updateCurrentImg();
}

function handleBoxClick(index) {
  if (isTransitioning) {
    return;
  }

  if (index === activeIndex && boxes[index].classList.contains("expanded")) {
    boxes.forEach((box) => box.classList.remove("closed", "expanded"));
    activeIndex = 0;
  } else {
    activeIndex = index;
    updateCurrentImg();
  }
}

document.addEventListener("keydown", handleArrowKey);

updateCurrentImg();

boxes.forEach((box, index) => {
  images-wrap.addEventListener("click", () => handleBoxClick(index));
});
